import cv2
import numpy as np

img0 = cv2.imread("img0.jpg")
img1 = cv2.imread("img1.jpg")
h, w = img0.shape[:2]
warp_mat = np.array([[0.99453366, -0.0013258901, -12.298146],
                        [-0.00091033406, 0.99582058, 2.9378426],
                        [-9.6194281e-06, -5.9069325e-06, 1]])
    
warp_mat = np.linalg.inv(warp_mat)
img0w1 = cv2.warpPerspective(img0, warp_mat, (w,h))
for i in range(50):
    cv2.imshow("imgc orig/pred", img0w1)
    cv2.waitKey(50)
    cv2.imshow("imgc orig/pred", img1)
    cv2.waitKey(50)


#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/video.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core/utility.hpp>
#include <stdio.h>
#include <string>
#include <time.h>
#include <iostream>
#include <fstream>
//using namespace cv;
using namespace std;

static int saveWarp(string fileName, const cv::Mat& warp, int motionType);

const std::string keys =
"{@image0        |               | template image }"
"{@mask0         |               | mask image }"
"{@video         |               | video in which this image roi needs to be tracked }"
"{@Hgs           |               | Homographies json file }"
;

int main(const int argc, const char * argv[])
{
  cv::CommandLineParser parser(argc, argv, keys);
  parser.about("ECC video application");
  parser.printMessage();
  string img0File = parser.get<string>(0);
  string mask0File = parser.get<string>(1);
  string vidFile = parser.get<string>(2);
  string HgsFile = parser.get<string>(3);
  //string maskFile = parser.get<string>(2);


  int num_iters = 1000;
  double term_eps = 1e-10;
  if (!parser.check()) {
    parser.printErrors();
    return -1;
  }

  // Read image0
  cv::Mat img0 = cv::imread(cv::samples::findFile(img0File), cv::IMREAD_GRAYSCALE);
  if (img0.empty()) {
    cerr << "Unable to load the img0" << endl;
    return -1;
  }
  cv::Mat mask0 = cv::imread(cv::samples::findFile(mask0File), cv::IMREAD_GRAYSCALE);
  if (mask0.empty()) {
    cerr << "Unable to load the mask0" << endl;
    return -1;
  }
  cv::FileStorage fs(HgsFile, cv::FileStorage::READ);
  cv::Mat roi0, Hgs;
  fs["Hgs"] >> Hgs;

  // Initialize VideoCapture 
  cv::VideoCapture cap(vidFile); 
  if (!cap.isOpened()) {
    std::cerr << "Error: Could not open video file." << std::endl;
    return -1;
  }

  const int warp_mode = cv::MOTION_HOMOGRAPHY;
  cv::TermCriteria crit = cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, num_iters, term_eps);
  cv::Mat warp_matrix = cv::Mat::eye(3, 3, CV_32F);
  int gaussian_size = 5;
  cv::Mat frame, img1; 
  double cc;
  int idx = 0;
#if 0
  cv::Mat mask = cv::Mat::zeros(img0.size(), CV_8UC1);
  int tlx, tly, brx, bry;
  tlx = roi0.at<int>(0,0);
  tly = roi0.at<int>(0,1);
  brx = roi0.at<int>(2,0);
  bry = roi0.at<int>(2,1);
  std::cout << tlx << " " << tly << " " << brx << " " << bry << std::endl;
  cv::Rect roiRect(tlx, tly, brx-tlx, bry-tly);
  mask(roiRect).setTo(cv::Scalar(255));
  cv::imshow("img0", img0);
  cv::imshow("mask", mask);
  cv::waitKey(0);
#endif
  while (true) {
    // 2. Capture frame-by-frame
    bool success = cap.read(frame);

    // If the frame is empty, the video has ended
    if (!success || frame.empty()) 
      break;

    cv::cvtColor(frame, img1, cv::COLOR_BGR2GRAY);
    //cv::imshow("img1", img1);
    //cv::waitKey(0);
    //cc = findTransformECC(img1, img0, warp_matrix, warp_mode, crit, cv::noArray(), gaussian_size);
    cc = findTransformECC(img1, img0, warp_matrix, warp_mode, crit, mask0, gaussian_size);
    (warp_matrix.reshape(1, 1)).copyTo(Hgs.row(idx));
    idx +=1;

  }

  // 4. Release resources automatically via destructor or manually
  cap.release();

  // find position of the .json 
  std::string coarseDotJson = "coarse.json";
  size_t pos = HgsFile.find(coarseDotJson);
  if (pos != std::string::npos) {
    HgsFile.replace(pos, coarseDotJson.length(), std::string("fine.json"));
  }
  cv::FileStorage fso(HgsFile, cv::FileStorage::WRITE);
  fso << "Hgs" << Hgs;


  return 0;
}

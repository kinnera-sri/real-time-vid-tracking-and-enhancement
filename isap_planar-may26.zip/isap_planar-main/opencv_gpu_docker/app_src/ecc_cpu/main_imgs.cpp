#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/video.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core/utility.hpp>
#include <stdio.h>
#include <string>
#include <time.h>
#include <iostream>
#include <fstream>
using namespace cv;
using namespace std;
static int saveWarp(string fileName, const Mat& warp, int motionType);
const std::string keys =
"{@image0        |               | image0 filename }"
"{@image1        |               | image1 filename }"
"{@mask          |               | mask }"
;

static int saveWarp(string fileName, const Mat& warp)
{
  // it saves the raw matrix elements in a file
  CV_Assert(warp.type() == CV_32FC1);
  const float* matPtr = warp.ptr<float>(0);
  int ret_value;
  ofstream outfile(fileName.c_str());
  if (!outfile) {
    cerr << "error in saving "
      << "Couldn't open file '" << fileName.c_str() << "'!" << endl;
    ret_value = 0;
  }
  else {//save the warp's elements
    outfile << matPtr[0] << " " << matPtr[1] << " " << matPtr[2] << endl;
    outfile << matPtr[3] << " " << matPtr[4] << " " << matPtr[5] << endl;
      outfile << matPtr[6] << " " << matPtr[7] << " " << matPtr[8] << endl;
    ret_value = 1;
  }
  return ret_value;
}
int main(const int argc, const char * argv[])
{
  CommandLineParser parser(argc, argv, keys);
  parser.about("ECC application");
  parser.printMessage();
  string img0File = parser.get<string>(0);
  string img1File = parser.get<string>(1);
  //string maskFile = parser.get<string>(2);
  int num_iters = 1000;
  double term_eps = 1e-10;
  if (!parser.check())
  {
    parser.printErrors();
    return -1;
  }
  Mat img0 = imread(samples::findFile(img0File), IMREAD_GRAYSCALE);
  Mat img1 = imread(samples::findFile(img1File), IMREAD_GRAYSCALE);
  //Mat mask = imread(samples::findFile(maskFile), IMREAD_GRAYSCALE);
  if (img0.empty()) {
    cerr << "Unable to load the img0" << endl;
    return -1;
  }
  if (img1.empty()) {
    cerr << "Unable to load the img1" << endl;
    return -1;
  }
  //if (mask.empty()) {
  //  cerr << "Unable to load the mask" << endl;
  //  return -1;
  //}
  const int warp_mode = MOTION_HOMOGRAPHY;
  // initialize or load the warp matrix
  Mat warp_matrix = Mat::eye(3, 3, CV_32F);
  int gaussian_size = 5;
  TermCriteria crit = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, num_iters, term_eps);
  double cc = findTransformECC(img1, img0,  warp_matrix, warp_mode, crit, noArray(), gaussian_size);
  if (cc == -1) {
    cerr << "The execution was interrupted. The correlation value is going to be minimized." << endl;
    cerr << "Check the warp initialization and/or the size of images." << endl << flush;
  }
  cout << "Final correlation: " << cc << endl << flush;
  cout << "warp mat: " << warp_matrix << endl << flush;
  // save the final warp matrix
  saveWarp("warp.txt", warp_matrix);

  return 0;
}

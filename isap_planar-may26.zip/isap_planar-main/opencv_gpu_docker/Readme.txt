cd opencv_gpu_docker/docker_src
docker build -t knr_cv_cuda .

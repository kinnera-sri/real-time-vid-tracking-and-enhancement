checkout depth anything, dsine and tinysam models here
